#ch2

[[ 2.1 – Enterprise Security]]
[[2.2 – Virtualization and Cloud Computing]]
[[2.3 – Secure Application Development]]
[[ 2.4 – Authentication and Authorization]]
[[2.5 – Resilience]]
[[ 2.6 – Embedded Systems]]
[[ 2.7 – Physical Security Controls]]
[[2.8 – Cryptographic Concepts]]










